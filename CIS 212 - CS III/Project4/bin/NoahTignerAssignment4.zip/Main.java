
import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) {
		
		WindowFrame frame = new WindowFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(600, 600);
		frame.setVisible(true);	
	}
}
